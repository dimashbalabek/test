function toggleMenu() {
    const menu = document.getElementById('navbarMenu');
    menu.classList.toggle('active');
}

function showTab(index) {
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach((content, i) => {
        content.classList.toggle('active', i === index);
    });
}


function hideModal(event) {
    if (event.target.id === 'modal') {
        document.getElementById('modal').style.display = 'none';
    }
}


function showModal() {
    document.getElementById('modal').style.display = 'flex';
}

let currentSlide = 0;

function showSlide(index) {
  const slides = document.querySelectorAll('.gallery-slide');
  const totalSlides = slides.length;

  if (index >= totalSlides) {
    currentSlide = 0;
  } else if (index < 0) {
    currentSlide = totalSlides - 1;
  } else {
    currentSlide = index;
  }

  const offset = -currentSlide * 100;
  document.querySelector('.gallery-container').style.transform = `translateX(${offset}%)`;
}

function nextSlide() {
  showSlide(currentSlide + 1);
}

function prevSlide() {
  showSlide(currentSlide - 1);
}
